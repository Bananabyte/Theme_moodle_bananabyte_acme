<?php

/**
 * This is the version.php file for acmebanana theme.
 */
defined('MOODLE_INTERNAL') || die;

$plugin->version   = 2024060101;
$plugin->component = 'theme_acmebanana';
$plugin->requires  = 2010112400;
$plugin->maturity  = MATURITY_RC;
$plugin->release = 2.00;

?>